﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MISA.Common
{
    public class Department
    {
        public Guid DepartmentID { get; set; }

        public String DepartmentName { get; set; }
    }
}
