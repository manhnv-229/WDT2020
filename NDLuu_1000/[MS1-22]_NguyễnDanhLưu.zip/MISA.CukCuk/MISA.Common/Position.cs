﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MISA.Common
{
    public class Position
    {
        public Guid PositionID { get; set; }

        public String PositionName { get; set; }
    }
}
