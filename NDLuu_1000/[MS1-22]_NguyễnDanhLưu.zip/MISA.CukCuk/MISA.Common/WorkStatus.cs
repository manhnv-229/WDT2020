﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MISA.Common
{
    public class WorkStatus
    {
        public int WorkStatusID { get; set; }
        public String WorkStatusName { get; set; }
    }
}
